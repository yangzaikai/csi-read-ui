function varargout = MyCsiTools(varargin)
% MYCSITOOLS MATLAB code for MyCsiTools.fig
%      MYCSITOOLS, by itself, creates a new MYCSITOOLS or raises the existing
%      singleton*.
%
%      H = MYCSITOOLS returns the handle to a new MYCSITOOLS or the handle to
%      the existing singleton*.
%
%      MYCSITOOLS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MYCSITOOLS.M with the given input arguments.
%
%      MYCSITOOLS('Property','Value',...) creates a new MYCSITOOLS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MyCsiTools_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MyCsiTools_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MyCsiTools

% Last Modified by GUIDE v2.5 29-Oct-2020 19:46:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MyCsiTools_OpeningFcn, ...
                   'gui_OutputFcn',  @MyCsiTools_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MyCsiTools is made visible.
function MyCsiTools_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MyCsiTools (see VARARGIN)

% Choose default command line output for MyCsiTools
handles.output = hObject;
global fileNameList
global RootPath
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MyCsiTools wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MyCsiTools_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in l_fileBox.
function l_fileBox_Callback(hObject, eventdata, handles)
% hObject    handle to l_fileBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns l_fileBox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from l_fileBox
    global RootPath
    global fileNameList
    fileIndex= get(handles.l_fileBox,'value');
    filename=[RootPath,'\',fileNameList{fileIndex}];%�洢�ļ���·��������
    csi_trace = read_bf_file(filename);
    num=length(csi_trace)
    set(handles.t_num,'string',num)
    csi_entry = csi_trace{1}
    set(handles.t_Ntx,'string',['Ntx:',num2str(csi_entry.Ntx)])
    set(handles.t_Nrx,'string',['Nrx:',num2str(csi_entry.Nrx)])
    set(handles.t_rssi_a,'string',['rssi_a:',num2str(csi_entry.rssi_a)])
    set(handles.t_rssi_b,'string',['rssi_b:',num2str(csi_entry.rssi_b)])
    set(handles.t_rssi_c,'string',['rssi_c:',num2str(csi_entry.rssi_c)])
    set(handles.t_noise,'string',['noise:',num2str(csi_entry.noise)])
    set(handles.t_rate,'string',['rate:',num2str(csi_entry.rate)])
    set(handles.t_agc,'string',['agc:',num2str(csi_entry.agc)])
    set(handles.t_perm,'string',['perm:',num2str(csi_entry.perm)])
    antennaCountNrx=csi_entry.Nrx
    for i =1:antennaCountNrx
        antennaList{i}=['��',num2str(i),'������']
    end
    antennaList{i+1}=['ȫѡ']
    set(handles.p_antennaIndex,'string',antennaList)
    antennaCountNtx=csi_entry.Ntx
    set(handles.t_timestamp_low_data,'string',csi_entry.timestamp_low)
    set(handles.t_bfee_count_data,'string',csi_entry.bfee_count)
    

% --- Executes during object creation, after setting all properties.
function l_fileBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to l_fileBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function fileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to fileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global RootPath
    %ѡ���ļ���·��
    RootPath = uigetdir
    disp(RootPath)
    DirOutput = dir(fullfile(RootPath))
    fileIndex=find(cat(1,DirOutput.isdir)<1)
    global fileNameList
    fileNameList={DirOutput(fileIndex).name}
    set(handles.l_fileBox,'string',fileNameList)
    

% --- Executes on selection change in p_antennaIndex.
function p_antennaIndex_Callback(hObject, eventdata, handles)
% hObject    handle to p_antennaIndex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns p_antennaIndex contents as cell array
%        contents{get(hObject,'Value')} returns selected item from p_antennaIndex


% --- Executes during object creation, after setting all properties.
function p_antennaIndex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p_antennaIndex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in p_dataIndex.
function p_dataIndex_Callback(hObject, eventdata, handles)
% hObject    handle to p_dataIndex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns p_dataIndex contents as cell array
%        contents{get(hObject,'Value')} returns selected item from p_dataIndex


% --- Executes during object creation, after setting all properties.
function p_dataIndex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p_dataIndex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in b_readCsi.
function b_readCsi_Callback(hObject, eventdata, handles)
% hObject    handle to b_readCsi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global RootPath
    global fileNameList
    fileIndex= get(handles.l_fileBox,'value');
    filename=[RootPath,'\',fileNameList{fileIndex}];%�洢�ļ���·��������
    csi_trace = read_bf_file(filename);
    low=1
    high=length(csi_trace)
    antennaIndex=get(handles.p_antennaIndex,'string')
    disp(antennaIndex)